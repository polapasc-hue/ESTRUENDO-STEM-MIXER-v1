package com.estruendo.stemmixer

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.estruendo.stemmixer.data.AudioLibrary
import com.estruendo.stemmixer.data.LibraryTrack
import com.estruendo.stemmixer.playback.AudioPlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Gold = Color(0xFFD6A64B)
private val Muted = Color(0xFF9A9DA6)

/** Cuántas pistas se envían a la cola a cada lado de la elegida (evita sobrecargar el binder con listas enormes). */
private const val QUEUE_BEFORE = 50
private const val QUEUE_AFTER = 150

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Con targetSdk 35 Android fuerza pantalla completa: se declara explícitamente y se aplican insets en la UI.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { EstruendoApp() }
    }

    @Composable
    private fun EstruendoApp() {
        var tracks by remember { mutableStateOf<List<LibraryTrack>>(emptyList()) }
        var loading by remember { mutableStateOf(false) }
        var granted by remember { mutableStateOf(hasAudioPermission()) }
        var message by remember { mutableStateOf("Permite el acceso para explorar la música del dispositivo.") }
        var controller by remember { mutableStateOf<MediaController?>(null) }
        var playing by remember { mutableStateOf(false) }
        var currentId by remember { mutableStateOf<String?>(null) }
        var currentTitle by remember { mutableStateOf("Ninguna canción seleccionada") }
        var currentArtist by remember { mutableStateOf("") }
        var duration by remember { mutableLongStateOf(0L) }
        var position by remember { mutableLongStateOf(0L) }
        var dragging by remember { mutableStateOf(false) }
        var askedNotifications by rememberSaveable { mutableStateOf(false) }
        val scope = rememberCoroutineScope()

        fun refreshPlaybackState(player: Player) {
            playing = player.isPlaying
            currentId = player.currentMediaItem?.mediaId?.takeIf { it.isNotEmpty() }
            currentTitle = player.mediaMetadata.title?.toString()
                ?: if (player.mediaItemCount == 0) "Ninguna canción seleccionada" else "Audio sin título"
            currentArtist = player.mediaMetadata.artist?.toString().orEmpty()
            duration = player.duration.takeIf { it > 0 } ?: 0L
            if (!dragging) position = player.currentPosition.coerceAtLeast(0L)
        }

        // Conexión con el servicio: se libera SIEMPRE el future y se quita el listener.
        DisposableEffect(Unit) {
            val token = SessionToken(this@MainActivity, ComponentName(this@MainActivity, AudioPlaybackService::class.java))
            val future = MediaController.Builder(this@MainActivity, token).buildAsync()
            var listener: Player.Listener? = null
            future.addListener({
                runCatching { future.get() }.onSuccess { mediaController ->
                    controller = mediaController
                    refreshPlaybackState(mediaController)
                    val l = object : Player.Listener {
                        override fun onEvents(player: Player, events: Player.Events) = refreshPlaybackState(player)
                    }
                    mediaController.addListener(l)
                    listener = l
                }
            }, ContextCompat.getMainExecutor(this@MainActivity))
            onDispose {
                listener?.let { controller?.removeListener(it) }
                controller = null
                MediaController.releaseFuture(future)
            }
        }

        LaunchedEffect(playing, controller) {
            while (playing && controller != null) {
                if (!dragging) position = controller?.currentPosition?.coerceAtLeast(0L) ?: 0L
                delay(500)
            }
        }

        fun scan() {
            if (loading) return
            loading = true
            scope.launch {
                val result = withContext(Dispatchers.IO) { runCatching { AudioLibrary(applicationContext).scan() } }
                tracks = result.getOrDefault(emptyList())
                message = result.exceptionOrNull()?.localizedMessage
                    ?: if (tracks.isEmpty()) "No se encontraron canciones indexadas. Usa Importar para buscar otra ubicación." else "Biblioteca actualizada"
                loading = false
            }
        }

        fun playTrack(track: LibraryTrack) {
            val player = controller
            if (player == null) {
                message = "El reproductor todavía se está iniciando. Intenta de nuevo."
                return
            }
            val index = tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
            val from = (index - QUEUE_BEFORE).coerceAtLeast(0)
            val to = (index + QUEUE_AFTER).coerceAtMost(tracks.size)
            player.setMediaItems(tracks.subList(from, to).map { it.toMediaItem() }, index - from, 0L)
            player.prepare()
            player.play()
        }

        val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
        fun askNotifications() {
            if (askedNotifications) return
            askedNotifications = true
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            granted = ok
            if (ok) {
                scan()
                askNotifications()
            } else message = "Sin permiso no podemos leer la biblioteca musical."
        }

        val documentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                // No todos los proveedores permiten permiso persistente: no debe cerrar la app.
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                val player = controller
                if (player != null) {
                    val name = displayName(uri)?.substringBeforeLast('.')
                        ?: uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')
                        ?: "Audio importado"
                    val metadata = MediaMetadata.Builder().setTitle(name).setArtist("Archivo seleccionado").build()
                    player.setMediaItem(MediaItem.Builder().setUri(uri).setMediaMetadata(metadata).build())
                    player.prepare()
                    player.play()
                } else message = "El reproductor todavía se está iniciando. Intenta de nuevo."
            }
        }

        // Al abrir (o rotar) con permiso ya concedido, se reescanea solo.
        LaunchedEffect(Unit) {
            if (granted) {
                scan()
                askNotifications()
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Gold, onPrimary = Ink,
                background = Ink, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )
        ) {
            Surface(Modifier.fillMaxSize(), color = Ink) {
                Column(Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("ESTRUENDO", color = Gold, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text("STEM MIXER", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                            Text("REPRODUCTOR · BIBLIOTECA", color = Muted, style = MaterialTheme.typography.labelSmall)
                        }
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = Gold, modifier = Modifier.size(38.dp))
                    }
                    Spacer(Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text("REPRODUCIENDO", color = Gold, fontWeight = FontWeight.Bold)
                            Text(currentTitle, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(currentArtist, color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            Spacer(Modifier.height(8.dp))
                            Slider(
                                value = if (duration > 0) position.coerceIn(0L, duration).toFloat() else 0f,
                                onValueChange = { dragging = true; position = it.toLong() },
                                onValueChangeFinished = {
                                    if (duration > 0) controller?.seekTo(position)
                                    dragging = false
                                },
                                valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()),
                                enabled = duration > 0
                            )
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(formatDuration(position), color = Muted, style = MaterialTheme.typography.labelSmall)
                                Spacer(Modifier.weight(1f))
                                Text(formatDuration(duration), color = Muted, style = MaterialTheme.typography.labelSmall)
                            }
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { controller?.seekToPreviousMediaItem() }, enabled = controller != null) {
                                    Icon(Icons.Default.SkipPrevious, contentDescription = "Anterior", tint = Color.White)
                                }
                                Spacer(Modifier.width(8.dp))
                                FilledIconButton(onClick = { if (playing) controller?.pause() else controller?.play() }, enabled = controller != null) {
                                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (playing) "Pausar" else "Reproducir")
                                }
                                Spacer(Modifier.width(8.dp))
                                IconButton(onClick = { controller?.seekToNextMediaItem() }, enabled = controller != null) {
                                    Icon(Icons.Default.SkipNext, contentDescription = "Siguiente", tint = Color.White)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text("BIBLIOTECA MUSICAL", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Busca música indexada o importa un archivo de audio.", color = Muted, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { if (granted) scan() else permissionLauncher.launch(audioPermission()) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null)
                                    Spacer(Modifier.width(5.dp))
                                    Text(if (loading) "ESCANEANDO" else "ESCANEAR")
                                }
                                OutlinedButton(onClick = { documentLauncher.launch(arrayOf("audio/*")) }, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.FolderOpen, contentDescription = null)
                                    Spacer(Modifier.width(5.dp))
                                    Text("IMPORTAR")
                                }
                            }
                            Text("${tracks.size} canciones encontradas", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("CANCIONES DEL DISPOSITIVO", color = Muted, style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    if (tracks.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.AudioFile, contentDescription = null, tint = Muted, modifier = Modifier.size(44.dp))
                                Text(message, color = Muted, textAlign = TextAlign.Center)
                            }
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(tracks, key = { it.id }) { track ->
                                TrackRow(track, selected = currentId == track.id.toString(), onClick = { playTrack(track) })
                            }
                        }
                    }
                    Text("ETAPA 2 · REPRODUCTOR BÁSICO Y SERVICIO MULTIMEDIA", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
    }

    private fun displayName(uri: Uri): String? = runCatching {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    private fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, audioPermission()) == PackageManager.PERMISSION_GRANTED
}

private fun LibraryTrack.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).build())
        .build()

@Composable
private fun TrackRow(track: LibraryTrack, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AudioFile, contentDescription = null, tint = Gold, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = if (selected) Gold else Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(track.artist, color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(track.format, color = Gold, style = MaterialTheme.typography.labelSmall)
                Text(formatDuration(track.durationMs), color = Muted, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private fun formatDuration(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}
