package com.estruendo.stemmixer.data

import android.net.Uri

/** Pista de la biblioteca. (Antes AudioTrack; renombrada para no chocar con android.media.AudioTrack.) */
data class LibraryTrack(
    val id: Long,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val mimeType: String,
    val format: String,
    val sizeBytes: Long,
    val uri: Uri
)
