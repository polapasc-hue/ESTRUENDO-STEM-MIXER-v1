package com.estruendo.stemmixer.data

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore

class AudioLibrary(private val context: Context) {
    fun scan(): List<LibraryTrack> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DISPLAY_NAME
        )
        // Excluye tonos, alarmas y notificaciones del sistema.
        val selection = "${MediaStore.Audio.Media.DURATION} > ? AND " +
            "${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND " +
            "${MediaStore.Audio.Media.IS_ALARM} = 0 AND " +
            "${MediaStore.Audio.Media.IS_NOTIFICATION} = 0"
        val tracks = mutableListOf<LibraryTrack>()
        context.contentResolver.query(
            collection,
            projection,
            selection,
            arrayOf("0"),
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val mime = cursor.getString(mimeCol) ?: "audio/unknown"
                val fileExt = cursor.getString(nameCol)?.substringAfterLast('.', "")?.uppercase().orEmpty()
                tracks += LibraryTrack(
                    id = id,
                    title = cursor.getString(titleCol) ?: "Audio sin título",
                    artist = cursor.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "Artista desconocido",
                    durationMs = cursor.getLong(durationCol),
                    mimeType = mime,
                    format = fileExt.ifEmpty { mime.substringAfter('/', mime).uppercase() },
                    sizeBytes = cursor.getLong(sizeCol),
                    uri = ContentUris.withAppendedId(collection, id)
                )
            }
        }
        return tracks
    }
}
